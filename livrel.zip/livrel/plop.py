from livrel import utils, document

sec = document.Section()
print(sec)

#sec.from_dict({"attributes":[{"key":"test_k","value":"test_v"}]})
#print(sec)


sec.from_dict({"type": "poem", "attributes":"test"})
print(sec)