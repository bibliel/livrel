from enum import Enum, auto

"""
class SectionType(Enum):
    DIALOG = 'dialog'
    NARRATIVE = 'narrative'
    EPIGRAPH = 'epigraph'
    POEM = 'poem'
"""

SECTION_TYPES = [
    'dialog',
    'narrative',
    'epigraph',
    'poem'
]